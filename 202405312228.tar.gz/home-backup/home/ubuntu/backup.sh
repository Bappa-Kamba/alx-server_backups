#!/bin/bash

# Directories
BACKUP_DIR="/backup/directory"
DATE=$(date +%Y%m%d%H%M)

# Create backup directory
mkdir -p ${BACKUP_DIR}/${DATE}

# Backup /etc
rsync -a --progress /etc ${BACKUP_DIR}/${DATE}/etc-backup

# Backup /home
rsync -a --progress /home ${BACKUP_DIR}/${DATE}/home-backup

# Backup MySQL
mysqldump -u root -p --all-databases > ${BACKUP_DIR}/${DATE}/alldb_backup.sql

# Backup PostgreSQL
pg_dumpall -U postgres > ${BACKUP_DIR}/${DATE}/postgresql_backup.sql

# Archive and compress backup
tar -cvpzf ${BACKUP_DIR}/${DATE}.tar.gz -C ${BACKUP_DIR}/${DATE} .

# Optional: Remove uncompressed backup directory
rm -rf ${BACKUP_DIR}/${DATE}

